--
-- PostgreSQL database dump
--

\restrict 5O1nZx563XlaWytefBwjbdiKLNr7Mr59eIR9rb8SagXDsAq78xEu71e1fTIub0T

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: gdpr_action; Type: TYPE; Schema: public; Owner: lssw
--

CREATE TYPE public.gdpr_action AS ENUM (
    'read',
    'write',
    'delete',
    'export'
);


ALTER TYPE public.gdpr_action OWNER TO lssw;

--
-- Name: linkedin_tier; Type: TYPE; Schema: public; Owner: lssw
--

CREATE TYPE public.linkedin_tier AS ENUM (
    'basic',
    'premium',
    'recruiter'
);


ALTER TYPE public.linkedin_tier OWNER TO lssw;

--
-- Name: search_status; Type: TYPE; Schema: public; Owner: lssw
--

CREATE TYPE public.search_status AS ENUM (
    'pending',
    'running',
    'completed',
    'failed',
    'rate_limited',
    'captcha'
);


ALTER TYPE public.search_status OWNER TO lssw;

--
-- Name: trim_search_history(); Type: FUNCTION; Schema: public; Owner: lssw
--

CREATE FUNCTION public.trim_search_history() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM search_history
    WHERE user_id = NEW.user_id
      AND id NOT IN (
          SELECT id FROM search_history
          WHERE user_id = NEW.user_id
          ORDER BY executed_at DESC
          LIMIT 50
      );
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.trim_search_history() OWNER TO lssw;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: gdpr_audit_log; Type: TABLE; Schema: public; Owner: lssw
--

CREATE TABLE public.gdpr_audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    action public.gdpr_action NOT NULL,
    resource character varying(255) NOT NULL,
    ip_address character varying(45) NOT NULL,
    user_agent text,
    details jsonb DEFAULT '{}'::jsonb,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.gdpr_audit_log OWNER TO lssw;

--
-- Name: TABLE gdpr_audit_log; Type: COMMENT; Schema: public; Owner: lssw
--

COMMENT ON TABLE public.gdpr_audit_log IS 'GDPR processing audit trail. Retained 365 days. NOT deleted on user erasure.';


--
-- Name: rate_limit_log; Type: TABLE; Schema: public; Owner: lssw
--

CREATE TABLE public.rate_limit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    window_start timestamp with time zone NOT NULL,
    search_count integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.rate_limit_log OWNER TO lssw;

--
-- Name: saved_searches; Type: TABLE; Schema: public; Owner: lssw
--

CREATE TABLE public.saved_searches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    search_params jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_template boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    run_count integer DEFAULT 0 NOT NULL,
    last_run_at timestamp with time zone
);


ALTER TABLE public.saved_searches OWNER TO lssw;

--
-- Name: TABLE saved_searches; Type: COMMENT; Schema: public; Owner: lssw
--

COMMENT ON TABLE public.saved_searches IS 'User-saved compound search configurations. No candidate data stored.';


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: lssw
--

CREATE TABLE public.schema_migrations (
    version character varying(20) NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL,
    description text
);


ALTER TABLE public.schema_migrations OWNER TO lssw;

--
-- Name: search_history; Type: TABLE; Schema: public; Owner: lssw
--

CREATE TABLE public.search_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    search_params jsonb DEFAULT '{}'::jsonb NOT NULL,
    result_count integer,
    executed_at timestamp with time zone DEFAULT now() NOT NULL,
    duration_ms integer,
    status public.search_status DEFAULT 'pending'::public.search_status NOT NULL,
    error_message text,
    saved_search_id uuid,
    purge_due_at timestamp with time zone
);


ALTER TABLE public.search_history OWNER TO lssw;

--
-- Name: users; Type: TABLE; Schema: public; Owner: lssw
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    linkedin_id character varying(64) NOT NULL,
    email character varying(255),
    full_name character varying(255) NOT NULL,
    headline character varying(512),
    profile_pic text,
    linkedin_tier public.linkedin_tier DEFAULT 'premium'::public.linkedin_tier NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_login_at timestamp with time zone DEFAULT now() NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    gdpr_consent_at timestamp with time zone,
    gdpr_consent_version character varying(20),
    gdpr_consent_ip character varying(45),
    data_retention_until timestamp with time zone,
    deletion_requested_at timestamp with time zone
);


ALTER TABLE public.users OWNER TO lssw;

--
-- Name: TABLE users; Type: COMMENT; Schema: public; Owner: lssw
--

COMMENT ON TABLE public.users IS 'User accounts. Minimal data per GDPR Art. 5(1)(c) data minimisation.';


--
-- Name: COLUMN users.gdpr_consent_at; Type: COMMENT; Schema: public; Owner: lssw
--

COMMENT ON COLUMN public.users.gdpr_consent_at IS 'When the user gave explicit consent per GDPR Art. 6(1)(a)';


--
-- Name: COLUMN users.data_retention_until; Type: COMMENT; Schema: public; Owner: lssw
--

COMMENT ON COLUMN public.users.data_retention_until IS 'Scheduled auto-deletion date per retention policy (90 days after last login)';


--
-- Data for Name: gdpr_audit_log; Type: TABLE DATA; Schema: public; Owner: lssw
--

COPY public.gdpr_audit_log (id, user_id, action, resource, ip_address, user_agent, details, "timestamp") FROM stdin;
0aa228e2-8eba-480c-ab99-8e81f2b02d7a	f445a66d-6fbe-467b-b10a-e88ae38c68c5	read	saved_searches.list	103.164.241.127	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	{}	2026-04-17 16:54:35.772112+00
a979a51a-48ea-4002-8b58-cfb9a05d11fa	f445a66d-6fbe-467b-b10a-e88ae38c68c5	read	linkedin.search	103.164.241.127	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	{"paramsKeys": ["title", "connectionDegree", "customString", "templateId"]}	2026-04-17 17:20:11.783954+00
f2aac62f-2a1b-46f5-8920-ea6521ea26b7	f445a66d-6fbe-467b-b10a-e88ae38c68c5	read	linkedin.search	103.164.241.127	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	{"paramsKeys": ["title", "connectionDegree", "customString", "templateId"]}	2026-04-17 17:23:21.925601+00
db0afeeb-7dd6-4a02-b483-e301e0fad126	f445a66d-6fbe-467b-b10a-e88ae38c68c5	read	linkedin.search	103.164.241.127	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	{"paramsKeys": ["title", "connectionDegree", "customString", "templateId"]}	2026-04-17 17:23:29.739422+00
d925e025-c911-488f-b53a-f84a7277197c	f445a66d-6fbe-467b-b10a-e88ae38c68c5	read	linkedin.search	103.164.241.127	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	{"paramsKeys": ["title", "connectionDegree", "customString", "templateId"]}	2026-04-17 17:23:47.473482+00
fe4c6400-b4cc-4ead-8b64-988e24f53522	f445a66d-6fbe-467b-b10a-e88ae38c68c5	read	linkedin.search	103.164.241.127	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	{"paramsKeys": ["title", "connectionDegree", "customString", "templateId"]}	2026-04-17 17:32:36.993013+00
a3a9cf7d-6343-47e7-ba11-684acf15d85e	f445a66d-6fbe-467b-b10a-e88ae38c68c5	read	saved_searches.list	103.164.241.127	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	{}	2026-04-17 17:44:59.128748+00
84f7921e-620f-42c0-954a-d2a77f2ea3fb	f445a66d-6fbe-467b-b10a-e88ae38c68c5	read	search_history.list	103.164.241.127	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	{}	2026-04-17 17:45:01.602362+00
85d9d613-3808-42c9-a88e-e7f71572dcbb	f445a66d-6fbe-467b-b10a-e88ae38c68c5	read	linkedin.search	103.164.241.127	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	{"paramsKeys": ["title", "connectionDegree", "customString", "templateId"]}	2026-04-17 18:05:43.369686+00
10b05979-6080-44de-ae43-5e522ab3c5c4	f445a66d-6fbe-467b-b10a-e88ae38c68c5	read	linkedin.search	103.164.241.127	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	{"paramsKeys": ["title", "connectionDegree", "customString", "templateId"]}	2026-04-17 18:16:34.906285+00
50be78fc-b527-4b1a-bf32-8e8b1df2696b	f445a66d-6fbe-467b-b10a-e88ae38c68c5	read	linkedin.search	103.164.241.127	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	{"paramsKeys": ["title", "company", "location", "connectionDegree", "customString", "templateId"]}	2026-04-17 18:19:42.687426+00
df0d2dcd-2c0c-42c5-b2a5-dfd001040bd1	f445a66d-6fbe-467b-b10a-e88ae38c68c5	read	linkedin.search	103.164.241.127	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	{"paramsKeys": ["title", "company", "location", "connectionDegree", "customString", "templateId"]}	2026-04-17 18:21:03.252676+00
142fbe55-0d97-4f51-9738-687b06ee1df0	f445a66d-6fbe-467b-b10a-e88ae38c68c5	read	linkedin.search	103.164.241.127	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	{"paramsKeys": ["title", "location", "connectionDegree", "customString", "templateId"]}	2026-04-17 18:21:59.039287+00
18e71b50-d045-4dfa-b7c2-649bd3d998a3	f445a66d-6fbe-467b-b10a-e88ae38c68c5	read	linkedin.search	103.164.241.127	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	{"paramsKeys": ["title", "location", "connectionDegree", "customString", "templateId"]}	2026-04-17 18:22:48.870578+00
b7e5b895-a0d0-4473-a8b8-79d310ffd049	f445a66d-6fbe-467b-b10a-e88ae38c68c5	read	linkedin.search	103.164.241.127	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	{"paramsKeys": ["title", "connectionDegree", "customString", "templateId"]}	2026-04-17 18:23:11.544252+00
6d1c52ed-2776-4743-96d1-683cc53c5c7b	f445a66d-6fbe-467b-b10a-e88ae38c68c5	read	linkedin.search	103.164.241.127	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	{"paramsKeys": ["title", "location", "connectionDegree"]}	2026-04-17 18:24:04.031237+00
5e392c82-ee0b-4960-a1c4-98d69d17e885	f445a66d-6fbe-467b-b10a-e88ae38c68c5	read	linkedin.search	103.164.241.127	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	{"paramsKeys": ["title", "connectionDegree", "customString"]}	2026-04-17 18:33:24.685016+00
84dad77f-5811-4b75-ac51-bf64e8b20f64	f445a66d-6fbe-467b-b10a-e88ae38c68c5	read	linkedin.search	103.164.241.127	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	{"paramsKeys": ["title", "connectionDegree", "customString", "templateId"]}	2026-04-18 05:08:27.050354+00
14cd013b-907b-4e3b-8c94-a31222e1b1e2	f445a66d-6fbe-467b-b10a-e88ae38c68c5	read	linkedin.search	103.164.241.127	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	{"paramsKeys": ["title", "connectionDegree", "customString", "templateId"]}	2026-04-18 05:08:58.771429+00
3eeaaeb8-068c-48bb-9b8e-1c73b8881472	f445a66d-6fbe-467b-b10a-e88ae38c68c5	read	linkedin.search	103.164.241.127	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	{"paramsKeys": ["title", "connectionDegree", "customString", "templateId"]}	2026-04-18 05:09:54.925545+00
8261dc06-e2ef-459f-ad3f-05a50b310886	f445a66d-6fbe-467b-b10a-e88ae38c68c5	read	linkedin.search	103.164.241.127	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	{"paramsKeys": ["title", "connectionDegree", "customString", "templateId"]}	2026-04-18 05:16:00.582628+00
b48837c8-4751-44c7-8d8a-4be7bf1cf54f	f445a66d-6fbe-467b-b10a-e88ae38c68c5	read	linkedin.search	103.164.241.127	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	{"paramsKeys": ["title", "connectionDegree", "customString", "templateId"]}	2026-04-18 05:16:50.586544+00
0950ec37-48dd-4f82-9819-cab518dd7f42	f445a66d-6fbe-467b-b10a-e88ae38c68c5	read	linkedin.search	103.164.241.127	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	{"paramsKeys": ["title", "connectionDegree", "customString", "templateId"]}	2026-04-18 05:21:51.673391+00
3c7a311b-2822-4c02-b65f-1d8b40ddd4ec	f445a66d-6fbe-467b-b10a-e88ae38c68c5	read	linkedin.search	103.164.241.127	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	{"paramsKeys": ["title", "connectionDegree", "customString", "templateId"]}	2026-04-18 05:39:48.43894+00
f16dcfef-41fb-40d7-a08b-e0927c4ce483	f445a66d-6fbe-467b-b10a-e88ae38c68c5	read	linkedin.search	103.164.241.127	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	{"paramsKeys": ["title", "connectionDegree", "customString", "templateId"]}	2026-04-18 05:52:03.68994+00
10bad176-2c36-424f-9def-af39f876eeef	f445a66d-6fbe-467b-b10a-e88ae38c68c5	read	linkedin.search	103.164.241.127	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	{"paramsKeys": ["title", "connectionDegree", "customString", "templateId"]}	2026-04-18 05:52:57.387339+00
3c0c7bc8-a54f-42d3-8031-b4b289a7c92d	f445a66d-6fbe-467b-b10a-e88ae38c68c5	read	linkedin.search	103.164.241.127	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	{"paramsKeys": ["title", "connectionDegree", "customString", "templateId"]}	2026-04-18 05:53:02.373545+00
82d2f4ac-3fe9-4e99-9873-6d80a88d986d	f445a66d-6fbe-467b-b10a-e88ae38c68c5	read	linkedin.search	103.164.241.127	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	{"paramsKeys": ["title", "connectionDegree", "customString", "templateId"]}	2026-04-18 05:53:24.16829+00
d8116182-e9a9-4194-ab2b-cdcec84484bf	f445a66d-6fbe-467b-b10a-e88ae38c68c5	read	linkedin.search	103.164.241.127	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	{"paramsKeys": ["title", "connectionDegree", "customString", "templateId"]}	2026-04-18 06:14:27.555394+00
\.


--
-- Data for Name: rate_limit_log; Type: TABLE DATA; Schema: public; Owner: lssw
--

COPY public.rate_limit_log (id, user_id, window_start, search_count) FROM stdin;
\.


--
-- Data for Name: saved_searches; Type: TABLE DATA; Schema: public; Owner: lssw
--

COPY public.saved_searches (id, user_id, name, description, search_params, is_template, created_at, updated_at, run_count, last_run_at) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: lssw
--

COPY public.schema_migrations (version, applied_at, description) FROM stdin;
001	2026-04-17 16:42:04.79227+00	Initial schema — users, saved_searches, search_history, gdpr_audit_log
\.


--
-- Data for Name: search_history; Type: TABLE DATA; Schema: public; Owner: lssw
--

COPY public.search_history (id, user_id, search_params, result_count, executed_at, duration_ms, status, error_message, saved_search_id, purge_due_at) FROM stdin;
81c54cfb-72c7-45b3-a87e-55fef1becc8c	f445a66d-6fbe-467b-b10a-e88ae38c68c5	{"title": "Data Scientist", "location": "Pune", "connectionDegree": ["F", "S"]}	\N	2026-04-17 18:24:04.027767+00	38119572	failed	page.evaluate: Execution context was destroyed, most likely because of a navigation	\N	2026-07-16 18:24:04.027+00
a1701815-c8c9-4261-87c0-4aecd0ab205c	f445a66d-6fbe-467b-b10a-e88ae38c68c5	{"title": "ML Engineer", "templateId": "immediate-joiner", "customString": "\\"Immediate joiner\\" OR \\"Notice period: 0\\" OR \\"Joining immediately\\"", "connectionDegree": ["F", "S"]}	\N	2026-04-17 17:20:11.780962+00	4886	failed	LINKEDIN_SESSION_EXPIRED	\N	2026-07-16 17:20:11.779+00
510d5773-3862-42a0-9cc4-8f5da0d6d911	f445a66d-6fbe-467b-b10a-e88ae38c68c5	{"title": "Data Science", "company": "Eaton", "location": "Pune", "templateId": "immediate-joiner", "customString": "\\"Immediate joiner\\" OR \\"Notice period: 0\\" OR \\"Joining immediately\\"", "connectionDegree": ["F", "S"]}	0	2026-04-17 18:21:03.247387+00	22450	completed	\N	\N	2026-07-16 18:21:03.245+00
fbc8fe8c-068e-4240-a79a-261d580522d2	f445a66d-6fbe-467b-b10a-e88ae38c68c5	{"title": "ML Engineer", "templateId": "immediate-joiner", "customString": "\\"Immediate joiner\\" OR \\"Notice period: 0\\" OR \\"Joining immediately\\"", "connectionDegree": ["F", "S"]}	\N	2026-04-17 17:23:21.922183+00	3937	failed	LINKEDIN_SESSION_EXPIRED	\N	2026-07-16 17:23:21.921+00
f960a405-3c97-4e1f-be76-5042713a1ca9	f445a66d-6fbe-467b-b10a-e88ae38c68c5	{"title": "ML Engineer", "templateId": "immediate-joiner", "customString": "\\"Immediate joiner\\" OR \\"Notice period: 0\\" OR \\"Joining immediately\\"", "connectionDegree": ["F", "S"]}	\N	2026-04-17 17:23:29.735612+00	3859	failed	LINKEDIN_SESSION_EXPIRED	\N	2026-07-16 17:23:29.734+00
0b9b9b08-ae3c-49d4-828a-510e04b449ab	f445a66d-6fbe-467b-b10a-e88ae38c68c5	{"title": "ML Engineer", "templateId": "immediate-joiner", "customString": "\\"Immediate joiner\\" OR \\"Notice period: 0\\" OR \\"Joining immediately\\"", "connectionDegree": ["F", "S"]}	\N	2026-04-17 17:23:47.470529+00	3975	failed	LINKEDIN_SESSION_EXPIRED	\N	2026-07-16 17:23:47.469+00
3dd8154e-8c8e-496b-b272-274dcbbabc6d	f445a66d-6fbe-467b-b10a-e88ae38c68c5	{"title": "Data Science", "location": "Pune", "templateId": "immediate-joiner", "customString": "\\"Immediate joiner\\" OR \\"Notice period: 0\\" OR \\"Joining immediately\\"", "connectionDegree": ["F", "S"]}	0	2026-04-17 18:21:59.035246+00	22821	completed	\N	\N	2026-07-16 18:21:59.03+00
3fcdeeaf-97e9-4c30-9846-e3560221a98a	f445a66d-6fbe-467b-b10a-e88ae38c68c5	{"title": "ML Engineer", "templateId": "immediate-joiner", "customString": "\\"Immediate joiner\\" OR \\"Notice period: 0\\" OR \\"Joining immediately\\"", "connectionDegree": ["F", "S"]}	\N	2026-04-17 17:32:36.988502+00	4586	failed	LINKEDIN_SESSION_EXPIRED	\N	2026-07-16 17:32:36.987+00
3f17f42c-bc27-43c1-a0ef-fe4338584ee5	f445a66d-6fbe-467b-b10a-e88ae38c68c5	{"title": "ML Engineer", "templateId": "immediate-joiner", "customString": "\\"Immediate joiner\\" OR \\"Notice period: 0\\" OR \\"Joining immediately\\"", "connectionDegree": ["F", "S"]}	\N	2026-04-17 18:05:43.366022+00	15214	failed	page.goto: Timeout 15000ms exceeded.\nCall log:\n  - navigating to "https://www.linkedin.com/search/results/people/?keywords=%22Immediate+joiner%22+OR+%22Notice+period%3A+0%22+OR+%22Joining+immediately%22&title=ML+Engineer&network=%5B%22F%22%2C%22S%22%5D&origin=FACETED_SEARCH&sid=1776449143505", waiting until "networkidle"\n	\N	2026-07-16 18:05:43.364+00
c627d82b-2c08-4225-8ca6-85133a1be182	f445a66d-6fbe-467b-b10a-e88ae38c68c5	{"title": "DevOps", "templateId": "immediate-joiner", "customString": "\\"Immediate joiner\\" OR \\"Notice period: 0\\" OR \\"Joining immediately\\"", "connectionDegree": ["F", "S"]}	\N	2026-04-17 18:16:34.90303+00	\N	running	\N	\N	2026-07-16 18:16:34.901+00
477031c6-6754-4780-a821-715e9064dbbd	f445a66d-6fbe-467b-b10a-e88ae38c68c5	{"title": "ML Engineer", "templateId": "open-to-work", "customString": "#OpenToWork OR \\"Open to work\\" OR \\"Actively looking\\"", "connectionDegree": ["F", "S"]}	\N	2026-04-18 05:39:48.434257+00	569714	failed	page.evaluate: Execution context was destroyed, most likely because of a navigation	\N	2026-07-17 05:39:48.433+00
6d2d9ab6-be4e-4987-9eec-9fc9e78fc80d	f445a66d-6fbe-467b-b10a-e88ae38c68c5	{"title": "DevOps", "company": "Eaton", "location": "Pune", "templateId": "immediate-joiner", "customString": "\\"Immediate joiner\\" OR \\"Notice period: 0\\" OR \\"Joining immediately\\"", "connectionDegree": ["F", "S"]}	0	2026-04-17 18:19:42.677425+00	21950	completed	\N	\N	2026-07-16 18:19:42.675+00
a158c421-d772-464a-a661-f45e82df43f9	f445a66d-6fbe-467b-b10a-e88ae38c68c5	{"title": "Project Manager", "location": "Pune", "templateId": "notice-30", "customString": "\\"30 days notice\\" OR \\"1 month notice\\" OR \\"serving notice\\"", "connectionDegree": ["F", "S"]}	0	2026-04-17 18:22:48.867001+00	21726	completed	\N	\N	2026-07-16 18:22:48.865+00
497a670c-ac4d-44df-804d-3924088df131	f445a66d-6fbe-467b-b10a-e88ae38c68c5	{"title": "ML Engineer", "templateId": "immediate-joiner", "customString": "\\"Immediate joiner\\" OR \\"Notice period: 0\\" OR \\"Joining immediately\\"", "connectionDegree": ["F", "S"]}	\N	2026-04-18 05:08:27.047621+00	1604	failed	LINKEDIN_SESSION_EXPIRED	\N	2026-07-17 05:08:27.046+00
7a4f691e-0275-4632-a869-5420f10b2058	f445a66d-6fbe-467b-b10a-e88ae38c68c5	{"title": "Data Scientist", "templateId": "open-to-work", "customString": "#OpenToWork OR \\"Open to work\\" OR \\"Actively looking\\"", "connectionDegree": ["F", "S"]}	0	2026-04-17 18:23:11.53878+00	21395	completed	\N	\N	2026-07-16 18:23:11.536+00
890c3d3f-a454-4629-abd8-190b0fe6115a	f445a66d-6fbe-467b-b10a-e88ae38c68c5	{"title": "ML Engineer", "templateId": "open-to-work", "customString": "#OpenToWork OR \\"Open to work\\" OR \\"Actively looking\\"", "connectionDegree": ["F", "S"]}	0	2026-04-18 05:16:00.580086+00	11	completed	\N	\N	2026-07-17 05:16:00.578+00
14a03386-1724-4347-93ac-8c90bc2333d8	f445a66d-6fbe-467b-b10a-e88ae38c68c5	{"title": "Data Scientist", "customString": "\\"Immediate joiner\\" OR \\"Notice period: 30\\" OR \\"Joining immediately\\"", "connectionDegree": ["F", "S"]}	0	2026-04-17 18:33:24.680963+00	21742	completed	\N	\N	2026-07-16 18:33:24.68+00
29ed7c86-7aed-4d02-9071-d70d60ba3f80	f445a66d-6fbe-467b-b10a-e88ae38c68c5	{"title": "ML Engineer", "templateId": "immediate-joiner", "customString": "\\"Immediate joiner\\" OR \\"Notice period: 0\\" OR \\"Joining immediately\\"", "connectionDegree": ["F", "S"]}	\N	2026-04-18 05:08:58.768612+00	1351	failed	LINKEDIN_SESSION_EXPIRED	\N	2026-07-17 05:08:58.768+00
115ef535-c559-4a07-93cf-7b6b0dd949c7	f445a66d-6fbe-467b-b10a-e88ae38c68c5	{"title": "ML Engineer", "templateId": "open-to-work", "customString": "#OpenToWork OR \\"Open to work\\" OR \\"Actively looking\\"", "connectionDegree": ["F", "S"]}	\N	2026-04-18 05:21:51.670724+00	996005	failed	page.evaluate: Execution context was destroyed, most likely because of a navigation	\N	2026-07-17 05:21:51.67+00
1c3a9002-671f-4a4c-94a4-9fd7dd04a7bb	f445a66d-6fbe-467b-b10a-e88ae38c68c5	{"title": "ML Engineer", "templateId": "open-to-work", "customString": "#OpenToWork OR \\"Open to work\\" OR \\"Actively looking\\"", "connectionDegree": ["F", "S"]}	0	2026-04-18 05:09:54.923452+00	22629	completed	\N	\N	2026-07-17 05:09:54.922+00
e7fc0625-9328-4b45-97a7-567aac2db8a8	f445a66d-6fbe-467b-b10a-e88ae38c68c5	{"title": "ML Engineer", "templateId": "open-to-work", "customString": "#OpenToWork OR \\"Open to work\\" OR \\"Actively looking\\"", "connectionDegree": ["F", "S"]}	0	2026-04-18 05:16:50.584105+00	10	completed	\N	\N	2026-07-17 05:16:50.583+00
330a1936-74f0-4697-ac8d-d120de463368	f445a66d-6fbe-467b-b10a-e88ae38c68c5	{"title": "ML Engineer", "templateId": "open-to-work", "customString": "#OpenToWork OR \\"Open to work\\" OR \\"Actively looking\\"", "connectionDegree": ["F", "S"]}	0	2026-04-18 05:52:03.687127+00	21291	completed	\N	\N	2026-07-17 05:52:03.685+00
59c10e9e-57ae-41f7-a6a0-457c06c1bbd1	f445a66d-6fbe-467b-b10a-e88ae38c68c5	{"title": "ML Engineer", "templateId": "open-to-work", "customString": "#OpenToWork OR \\"Open to work\\" OR \\"Actively looking\\"", "connectionDegree": ["F", "S"]}	0	2026-04-18 05:52:57.384305+00	11	completed	\N	\N	2026-07-17 05:52:57.383+00
024165e4-a28d-425c-9590-7673a1dc8871	f445a66d-6fbe-467b-b10a-e88ae38c68c5	{"title": "ML Engineer", "templateId": "open-to-work", "customString": "#OpenToWork OR \\"Open to work\\" OR \\"Actively looking\\"", "connectionDegree": ["F", "S"]}	0	2026-04-18 05:53:02.369002+00	3	completed	\N	\N	2026-07-17 05:53:02.368+00
f573a72d-3611-41c6-8aae-1daf243ae125	f445a66d-6fbe-467b-b10a-e88ae38c68c5	{"title": "Data Scientist", "templateId": "open-to-work", "customString": "#OpenToWork OR \\"Open to work\\" OR \\"Actively looking\\"", "connectionDegree": ["F", "S"]}	0	2026-04-18 05:53:24.16657+00	21013	completed	\N	\N	2026-07-17 05:53:24.166+00
6d910fc7-92e2-4505-913a-6696029e5fe0	f445a66d-6fbe-467b-b10a-e88ae38c68c5	{"title": "ML Engineer", "templateId": "open-to-work", "customString": "#OpenToWork OR \\"Open to work\\" OR \\"Actively looking\\"", "connectionDegree": ["F", "S"]}	0	2026-04-18 06:14:27.55264+00	20230	completed	\N	\N	2026-07-17 06:14:27.551+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: lssw
--

COPY public.users (id, linkedin_id, email, full_name, headline, profile_pic, linkedin_tier, created_at, last_login_at, is_active, gdpr_consent_at, gdpr_consent_version, gdpr_consent_ip, data_retention_until, deletion_requested_at) FROM stdin;
f445a66d-6fbe-467b-b10a-e88ae38c68c5	9AePq7-KZI	deepakakulkarni@gmail.com	Deepak Kulkarni	\N	https://media.licdn.com/dms/image/v2/D4D03AQH2fE7LCO3sjg/profile-displayphoto-shrink_100_100/profile-displayphoto-shrink_100_100/0/1730363253780?e=1778112000&v=beta&t=utdTymo4g1ZXpKhrJ6gvL1KR7cuykdDCFsTfB58h7GE	premium	2026-04-17 16:37:33.817139+00	2026-04-17 16:37:33.814+00	t	2026-04-17 16:37:39.697+00	1.0	103.164.241.127	2026-07-16 16:37:39.697+00	\N
\.


--
-- Name: gdpr_audit_log gdpr_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: lssw
--

ALTER TABLE ONLY public.gdpr_audit_log
    ADD CONSTRAINT gdpr_audit_log_pkey PRIMARY KEY (id);


--
-- Name: rate_limit_log rate_limit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: lssw
--

ALTER TABLE ONLY public.rate_limit_log
    ADD CONSTRAINT rate_limit_log_pkey PRIMARY KEY (id);


--
-- Name: rate_limit_log rate_limit_log_user_id_window_start_key; Type: CONSTRAINT; Schema: public; Owner: lssw
--

ALTER TABLE ONLY public.rate_limit_log
    ADD CONSTRAINT rate_limit_log_user_id_window_start_key UNIQUE (user_id, window_start);


--
-- Name: saved_searches saved_searches_pkey; Type: CONSTRAINT; Schema: public; Owner: lssw
--

ALTER TABLE ONLY public.saved_searches
    ADD CONSTRAINT saved_searches_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: lssw
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: search_history search_history_pkey; Type: CONSTRAINT; Schema: public; Owner: lssw
--

ALTER TABLE ONLY public.search_history
    ADD CONSTRAINT search_history_pkey PRIMARY KEY (id);


--
-- Name: users users_linkedin_id_key; Type: CONSTRAINT; Schema: public; Owner: lssw
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_linkedin_id_key UNIQUE (linkedin_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: lssw
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_gdpr_audit_timestamp; Type: INDEX; Schema: public; Owner: lssw
--

CREATE INDEX idx_gdpr_audit_timestamp ON public.gdpr_audit_log USING btree ("timestamp" DESC);


--
-- Name: idx_gdpr_audit_user_id; Type: INDEX; Schema: public; Owner: lssw
--

CREATE INDEX idx_gdpr_audit_user_id ON public.gdpr_audit_log USING btree (user_id);


--
-- Name: idx_saved_searches_params; Type: INDEX; Schema: public; Owner: lssw
--

CREATE INDEX idx_saved_searches_params ON public.saved_searches USING gin (search_params);


--
-- Name: idx_saved_searches_user_id; Type: INDEX; Schema: public; Owner: lssw
--

CREATE INDEX idx_saved_searches_user_id ON public.saved_searches USING btree (user_id);


--
-- Name: idx_search_history_executed_at; Type: INDEX; Schema: public; Owner: lssw
--

CREATE INDEX idx_search_history_executed_at ON public.search_history USING btree (executed_at);


--
-- Name: idx_search_history_user_id; Type: INDEX; Schema: public; Owner: lssw
--

CREATE INDEX idx_search_history_user_id ON public.search_history USING btree (user_id);


--
-- Name: idx_users_gdpr_consent; Type: INDEX; Schema: public; Owner: lssw
--

CREATE INDEX idx_users_gdpr_consent ON public.users USING btree (gdpr_consent_at);


--
-- Name: idx_users_linkedin_id; Type: INDEX; Schema: public; Owner: lssw
--

CREATE INDEX idx_users_linkedin_id ON public.users USING btree (linkedin_id);


--
-- Name: rate_limit_log rate_limit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lssw
--

ALTER TABLE ONLY public.rate_limit_log
    ADD CONSTRAINT rate_limit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: saved_searches saved_searches_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lssw
--

ALTER TABLE ONLY public.saved_searches
    ADD CONSTRAINT saved_searches_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: search_history search_history_saved_search_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lssw
--

ALTER TABLE ONLY public.search_history
    ADD CONSTRAINT search_history_saved_search_id_fkey FOREIGN KEY (saved_search_id) REFERENCES public.saved_searches(id) ON DELETE SET NULL;


--
-- Name: search_history search_history_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: lssw
--

ALTER TABLE ONLY public.search_history
    ADD CONSTRAINT search_history_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 5O1nZx563XlaWytefBwjbdiKLNr7Mr59eIR9rb8SagXDsAq78xEu71e1fTIub0T

