import { chromium, Browser, BrowserContext, Page } from 'playwright';
import { config } from '../../config';
import { logger } from '../../utils/logger';
import { redisClient, keys } from '../../redis/client';
import { CandidateCard, SearchParams, SearchResult } from '../../types';

// ─── URL Builder ──────────────────────────────────────────────────────────────

function buildLinkedInSearchUrl(params: SearchParams): string {
  const base = 'https://www.linkedin.com/search/results/people/';
  const query = new URLSearchParams();

  // Custom Boolean string becomes the main keyword
  if (params.customString) {
    query.set('keywords', params.customString);
  } else if (params.keywords) {
    query.set('keywords', params.keywords);
  }

  // Structured filters
  if (params.title)    query.set('title', params.title);
  if (params.company)  query.set('company', params.company);
  if (params.school)   query.set('schoolName', params.school);

  // Network (connection degree)
  if (params.connectionDegree?.length) {
    query.set('network', JSON.stringify(params.connectionDegree));
  }

  // LinkedIn Premium filters
  if (params.yearsOfExperience) query.set('yearsOfExperience', params.yearsOfExperience);
  if (params.companySize)       query.set('companySize', params.companySize);

  query.set('origin', 'FACETED_SEARCH');
  query.set('sid', `${Date.now()}`);

  let url = `${base}?${query.toString()}`;

  // Append location separately (complex geoUrn structure)
  if (params.location) {
    url += `&geoUrn=${encodeURIComponent(`["${params.location}"]`)}`;
  }

  return url;
}

// ─── Anti-Detection Helpers ───────────────────────────────────────────────────

async function randomDelay(minMs: number, maxMs: number): Promise<void> {
  const delay = Math.floor(Math.random() * (maxMs - minMs + 1)) + minMs;
  await new Promise((r) => setTimeout(r, delay));
}

const USER_AGENTS = [
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
  'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0',
];

function randomUserAgent(): string {
  return USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];
}

// ─── Context Serialization ────────────────────────────────────────────────────

async function saveContext(userId: string, context: BrowserContext): Promise<void> {
  const state = await context.storageState();
  await redisClient.setex(
    keys.browserCtx(userId),
    3600, // 1 hour
    JSON.stringify(state),
  );
}

async function loadContext(browser: Browser, userId: string): Promise<BrowserContext> {
  const stored = await redisClient.get(keys.browserCtx(userId));
  const userAgent = randomUserAgent();

  if (stored) {
    logger.debug('Restoring browser context from Redis', { userId });
    return browser.newContext({
      storageState: JSON.parse(stored),
      userAgent,
      viewport: { width: 1280, height: 800 },
      locale: 'en-US',
      timezoneId: 'Europe/Berlin', // EU data residency
      geolocation: { latitude: 52.52, longitude: 13.4 }, // Berlin
      permissions: [],
    });
  }

  logger.debug('Creating new browser context', { userId });
  return browser.newContext({
    userAgent,
    viewport: { width: 1280, height: 800 },
    locale: 'en-US',
    timezoneId: 'Europe/Berlin',
    permissions: [],
  });
}

// ─── Result Scraper ───────────────────────────────────────────────────────────

async function scrapeResults(page: Page): Promise<CandidateCard[]> {
  await page.waitForTimeout(1500);

  // Human-like scroll behavior
  await page.evaluate(() => {
    window.scrollBy({ top: 300, behavior: 'smooth' });
  });
  await page.waitForTimeout(800);
  await page.evaluate(() => {
    window.scrollBy({ top: 400, behavior: 'smooth' });
  });
  await page.waitForTimeout(500);

  const candidates = await page.evaluate((): CandidateCard[] => {
    const cards: CandidateCard[] = [];

    // LinkedIn's search result containers
    const resultContainers = document.querySelectorAll(
      '.reusable-search__result-container, li.reusable-search__result-container',
    );

    resultContainers.forEach((container) => {
      try {
        // Name
        const nameEl = container.querySelector(
          'span.entity-result__title-text a span[aria-hidden="true"], .entity-result__title-text span[aria-hidden]',
        );
        const name = nameEl?.textContent?.trim() || '';
        if (!name || name === 'LinkedIn Member') return;

        // Profile URL
        const profileLinkEl = container.querySelector(
          'a.app-aware-link[href*="/in/"]',
        );
        const profileUrl = (profileLinkEl as HTMLAnchorElement)?.href || '';

        // Title
        const titleEl = container.querySelector(
          '.entity-result__primary-subtitle',
        );
        const titleText = titleEl?.textContent?.trim() || '';
        const [title = '', company = ''] = titleText.split(' at ');

        // Location
        const locationEl = container.querySelector(
          '.entity-result__secondary-subtitle',
        );
        const location = locationEl?.textContent?.trim() || '';

        // Headline
        const headlineEl = container.querySelector(
          '.entity-result__summary',
        );
        const headline = headlineEl?.textContent?.trim() || '';

        // Profile pic
        const picEl = container.querySelector('img.presence-entity__image, img.EntityPhoto-circle-3');
        const profilePicUrl = (picEl as HTMLImageElement)?.src || '';

        // Connection degree
        const degreeEl = container.querySelector(
          '.dist-value, [class*="dist-value"]',
        );
        const degreeText = degreeEl?.textContent?.trim() || '';
        let connectionDegree: CandidateCard['connectionDegree'] = 'Out of Network';
        if (degreeText.includes('1st')) connectionDegree = '1st';
        else if (degreeText.includes('2nd')) connectionDegree = '2nd';
        else if (degreeText.includes('3rd')) connectionDegree = '3rd';

        // Open to Work badge
        const openToWorkEl = container.querySelector(
          '[data-test-is-open-to-work],' +
          '.open-to-work-badge,' +
          '[aria-label*="Open to work"],' +
          '.pv-member-badges__badge--opentowork',
        );
        const isOpenToWork = !!openToWorkEl || headline.includes('#OpenToWork') || headline.includes('Open to work');

        // Mutual connections
        const mutualEl = container.querySelector('.member-insights__container');
        const mutualText = mutualEl?.textContent?.trim() || '';
        const mutualMatch = mutualText.match(/(\d+)\s*mutual/i);
        const mutualConnections = mutualMatch ? parseInt(mutualMatch[1], 10) : undefined;

        const badges: string[] = [];
        if (isOpenToWork) badges.push('Open to Work');

        // Split name into first/last
        const nameParts = name.split(' ');
        const firstName = nameParts[0];
        const lastName = nameParts.slice(1).join(' ');

        cards.push({
          name,
          firstName,
          lastName,
          title: title.trim(),
          company: company.trim(),
          location,
          headline,
          profileUrl,
          profilePicUrl,
          connectionDegree,
          isOpenToWork,
          badges,
          mutualConnections,
        });
      } catch {
        // Skip malformed cards
      }
    });

    return cards;
  });

  return candidates;
}

// ─── Main Adapter ─────────────────────────────────────────────────────────────

export class PlaywrightLinkedInAdapter {
  private browser: Browser | null = null;
  private activeSessions: Map<string, BrowserContext> = new Map();

  async initialize(): Promise<void> {
    logger.info('Initializing Playwright browser');
    this.browser = await chromium.launch({
      headless: true,
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-accelerated-2d-canvas',
        '--no-first-run',
        '--no-zygote',
        '--disable-gpu',
        '--disable-web-security',
        '--disable-features=IsolateOrigins',
        '--disable-site-isolation-trials',
      ],
    });
    logger.info('Playwright browser initialized');
  }

  async shutdown(): Promise<void> {
    for (const ctx of this.activeSessions.values()) {
      await ctx.close().catch(() => {});
    }
    this.activeSessions.clear();
    await this.browser?.close();
    logger.info('Playwright browser shut down');
  }

  private async getContext(userId: string): Promise<BrowserContext> {
    if (!this.browser) throw new Error('Browser not initialized');

    let ctx = this.activeSessions.get(userId);
    if (!ctx || ctx.pages().length === 0) {
      ctx = await loadContext(this.browser, userId);
      this.activeSessions.set(userId, ctx);
    }
    return ctx;
  }

  // ─── Inject LinkedIn session cookies ─────────────────────────────────────

  async injectLinkedInSession(
    userId: string,
    liAt: string,       // li_at cookie (LinkedIn auth)
    jsessionid: string, // JSESSIONID cookie
  ): Promise<void> {
    const ctx = await this.getContext(userId);
    await ctx.addCookies([
      {
        name: 'li_at',
        value: liAt,
        domain: '.linkedin.com',
        path: '/',
        httpOnly: true,
        secure: true,
        sameSite: 'None',
      },
      {
        name: 'JSESSIONID',
        value: jsessionid,
        domain: '.linkedin.com',
        path: '/',
        httpOnly: true,
        secure: true,
      },
    ]);
    await saveContext(userId, ctx);
  }

  // ─── Execute Search ───────────────────────────────────────────────────────

  async executeSearch(
    params: SearchParams,
    userId: string,
    page = 1,
  ): Promise<{ results: CandidateCard[]; hasMore: boolean }> {
    if (!this.browser) throw new Error('Browser not initialized');

    // Check captcha ban
    const banned = await redisClient.get(keys.captchaBan(userId));
    if (banned) {
      throw new Error('CAPTCHA_BANNED');
    }

    const ctx = await this.getContext(userId);
    const browserPage = await ctx.newPage();

    try {
      // Block unnecessary resources to speed up load
      await browserPage.route('**/*.{png,jpg,jpeg,gif,svg,woff,woff2,ttf}', (route) => {
        route.abort();
      });

      const url = buildLinkedInSearchUrl(params);
      const pageUrl = page > 1 ? `${url}&start=${(page - 1) * 10}` : url;

      logger.info('Navigating to LinkedIn search', {
        userId,
        url: pageUrl.substring(0, 100),
      });

      const response = await browserPage.goto(pageUrl, {
        waitUntil: 'networkidle',
        timeout: config.playwright.browserTimeoutMs,
      });

      if (!response) throw new Error('LINKEDIN_NO_RESPONSE');

      const finalUrl = browserPage.url();

      // Check if redirected to auth (session expired)
      if (finalUrl.includes('/login') || finalUrl.includes('/checkpoint')) {
        throw new Error('LINKEDIN_SESSION_EXPIRED');
      }

      // Check for CAPTCHA
      const hasCaptcha = await browserPage.$('[data-test-id="challenge-form"], .challenge-page');
      if (hasCaptcha) {
        await redisClient.setex(keys.captchaBan(userId), 1800, '1'); // 30 min ban
        throw new Error('LINKEDIN_CAPTCHA');
      }

      // Wait for results
      await browserPage.waitForSelector(
        '.reusable-search__result-container, .search-results-container',
        { timeout: config.playwright.browserTimeoutMs },
      ).catch(() => {
        logger.warn('Results container not found, page may be empty');
      });

      await randomDelay(
        config.playwright.navDelayMinMs,
        config.playwright.navDelayMaxMs,
      );

      const results = await scrapeResults(browserPage);

      // Check for more pages
      const hasMore = await browserPage.$('.artdeco-pagination__button--next:not([disabled])') !== null;

      // Save updated session state
      await saveContext(userId, ctx);

      logger.info('Search completed', { userId, resultCount: results.length });

      return { results, hasMore };

    } finally {
      await browserPage.close();
    }
  }

  // ─── Clear user session ───────────────────────────────────────────────────

  async clearUserSession(userId: string): Promise<void> {
    const ctx = this.activeSessions.get(userId);
    if (ctx) {
      await ctx.close().catch(() => {});
      this.activeSessions.delete(userId);
    }
    await redisClient.del(keys.browserCtx(userId));
  }
}

// Singleton
export const linkedInAdapter = new PlaywrightLinkedInAdapter();
